# DL Tool

Outil de téléchargement GitHub Pages + Actions.

## Setup
1. Active GitHub Pages (/public).
2. Génère token GitHub (scopes: repo, workflow).
3. Ajoute secret GITHUB_TOKEN dans Settings > Secrets.
4. Remplace TOKEN/REPO dans index.html.

## Usage
- Ouvre https://tonnom.github.io/dl-tool
- Colle lien → Clique
- Attends → Télécharge depuis Releases.
